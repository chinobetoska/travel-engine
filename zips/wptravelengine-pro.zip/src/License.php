<?php
/**
 * License.
 *
 * @package WPTravelEnginePro
 * @since 1.0.0
 */

namespace WPTravelEnginePro;

use DateTime;
use Exception;
use WPTravelEnginePro\Admin\EDDPluginsResponse;

class License {

	const STATUS_INVALID_ITEM_ID = 'invalid_item_id';
	const STATUS_VALID           = 'valid';
	const STATUS_INVALID         = 'invalid';
	const STATUS_EXPIRED         = 'expired';
	const STATUS_INACTIVE        = 'site_inactive';
	const STATUS_DEACTIVATED 	 = 'deactivated';

	public string $slug = '';

	public int $item_id = 0;

	public string $item_name = '';

	protected string $license_key = '';

	protected DateTime $expiry_datetime;

	protected string $status = 'invalid';

	protected string $customer_name = '';

	protected string $customer_email = '';

	protected int $limit = 0;

	protected int $activations_left = 0;

	/**
	 * @var Extension
	 */
	protected Extension $item;

	public function __construct( string $license_key, $item_id, $slug = '' ) {
		$this->slug        = $slug;
		$this->item_id     = $item_id;
		$this->license_key = $license_key;

		$this->update();
	}

	public function license(): string {
		return $this->license_key;
	}

	/**
	 * Set Expiry Date.
	 *
	 * $datetime string|DateTime
	 *
	 * @since 2.4.0
	 */
	public function set_expiry_datetime( $datetime ) {
		try {
			if ( ! $datetime instanceof DateTime ) {
				if ( 'lifetime' === $datetime ) {
					$datetime = new DateTime( '9999-12-31 23:59:59' );
				} else {
					$datetime = new DateTime( $datetime );
				}
			}
		} catch ( Exception $e ) {
			$datetime = new DateTime();
		}

		$this->expiry_datetime = $datetime;
	}

	/**
	 * Get Expiry Date.
	 *
	 * @since 2.4.0
	 */
	public function expiry_datetime(): DateTime {
		return $this->expiry_datetime;
	}

	/**
	 * Check if the license is expired.
	 *
	 * @since 2.4.0
	 */
	public function expired(): bool {
		$now = new DateTime();

		return $now > $this->expiry_datetime;
	}

	/**
	 * Get License Key.
	 *
	 * @since 2.4.0
	 */
	public function set_status( string $status ) {
		$this->status = $status;
	}

	/**
	 * Get License Key.
	 *
	 * @since 2.4.0
	 */
	public function get_status(): string {
		return $this->status;
	}

	/**
	 * Is License Valid.
	 *
	 * @since 2.4.0
	 */
	public function valid(): bool {
		return static::STATUS_VALID === $this->status;
	}

	/**
	 * Is License Invalid.
	 *
	 * @since 2.4.0
	 */
	public function invalid(): bool {
		return $this->status === static::STATUS_INVALID;
	}

	public function set_customer_name( string $customer_name ) {
		$this->customer_name = $customer_name;
	}

	public function customer_name(): string {
		return $this->customer_name;
	}

	public function set_customer_email( string $customer_email ) {
		$this->customer_email = $customer_email;
	}

	public function customer_email(): string {
		return $this->customer_email;
	}

	public function set_limit( $limit ): void {
		if ( 'unlimited' === $limit ) {
			$limit = -1;
		}
		$this->limit = (int) $limit;
	}

	public function limit(): string {
		return $this->limit;
	}

	public function set_activations_left( $activations_left ) {
		if ( $activations_left === 'unlimited' ) {
			$activations_left = - 1;
		}
		$this->activations_left = (int) $activations_left;
	}

	public function activations_left(): string {
		return $this->activations_left;
	}

	public function days_left() {
		$now  = new DateTime();
		$diff = $now->diff( $this->expiry_datetime );

		return $diff->days;
	}

	public function is_lifetime(): bool {
		return $this->expiry_datetime->format( 'Y-m-d H:i:s' ) === '9999-12-31 23:59:59';
	}

	protected function request( $action, $cache = true ) {

		if ( empty( $this->license() ) ) {
			return new \WP_Error( 'missing_license', 'License key is missing' );
		}

		$plugin_api = new EDDPluginsResponse(
			$this->item_id,
			WP_TRAVEL_ENGINE_STORE_URL,
			array(
				'license' => $this->license(),
				'slug'    => $this->slug,
			)
		);

		return $plugin_api->get_plugin_information( $action, $cache );
	}

	public function check() {
		return $this->request( 'check_license' );
	}

	public function activate() {
		$result = $this->request( 'activate_license', false );

		if ( $result->license ?? false ) {
			$this->refresh();
			wptravelengine_pro_get_extensions_version( '', true );
			wp_schedule_single_event( time(), 'wptravelengine_pro_cron_license_check' );
			if ( (int) $result->item_id === 138060 ) {
				wp_schedule_single_event( time(), 'wptravelengine_pro_cron_server_sync' );
			}
			$result->error   = $this->status_message( $result->license );
			$result->message = $this->status_message( $result->license );
		}

		return $result;
	}

	public function deactivate() {
		$result = $this->request( 'deactivate_license', false );

		if ( $result->license ?? false ) {
			$this->refresh();
			wp_schedule_single_event( time(), 'wptravelengine_pro_cron_license_check' );
			$result->error   = $this->status_message( $result->license );
			$result->message = $this->status_message( $result->license );
		}

		return $result;
	}

	public function get_version() {
		return $this->request( 'get_version' );
	}

	/**
	 * Update the License datas.
	 *
	 * @return License
	 * @since 1.0.15 Redirected to refresh.
	 */
	public function update(): License {
		$this->refresh();
		return $this;
	}

	/**
	 * Returns if the SSL of the store should be verified.
	 *
	 * @return bool
	 * @since  1.6.13
	 */
	protected function verify_ssl(): bool {
		return (bool) apply_filters( 'edd_sl_api_request_verify_ssl', true, $this );
	}

	public static function get_status_message( string $status, string $license_key = '' ): string {
		switch ( $status ) {
			case 'missing':
				return __( 'License key is missing', 'wptravelengine-pro' );
			case 'valid':
				return __( 'License key is valid and site is active.', 'wptravelengine-pro' );
			case 'invalid':
				return sprintf(
					__( 'Invalid license key. Please verify your key or obtain a valid license key from %s.', 'wptravelengine-pro' ),
					'<a href="https://wptravelengine.com/pricing" target="_blank">here</a>'
				);
			case 'key_mismatch':
				return __( 'License is not valid for this product', 'wptravelengine-pro' );
			case 'invalid_item_id':
				return __( 'Invalid Item ID', 'wptravelengine-pro' );
			case 'site_inactive':
				return __( 'Your site is not active for this license', 'wptravelengine-pro' );
			case 'expired':
				return sprintf(
					__( 'Your license key has expired. Please renew your license key to continue receiving updates and support. %1$sRenew Now%2$s', 'wptravelengine-pro' ),
					'<a href="https://wptravelengine.com/checkout/?edd_license_key=' . $license_key . '" target="_blank">',
					'</a>'
				);
			case 'deactivated':
				return __( 'Your site is deactivated for this license.', 'wptravelengine-pro' );
			case 'failed':
				return __( 'Request failed', 'wptravelengine-pro' );
			default:
				return '';
		}
	}

	public function status_message( string $status = '' ): string {
		return static::get_status_message(
			empty( $status ) ? $this->get_status() : $status,
			$this->license_key
		);
	}

	public function is_expiring( int $days = 7 ): bool {
		return $this->days_left() < $days;
	}

	public function to_array(): array {
		return array(
			'license'          => $this->license(),
			'status'           => $this->get_status(),
			'customer_name'    => $this->customer_name(),
			'customer_email'   => $this->customer_email(),
			'expiry_datetime'  => $this->expiry_datetime()->format( 'Y-m-d H:i:s' ),
			'limit'            => $this->limit(),
			'activations_left' => $this->activations_left(),
		);
	}

	/**
	 * Refresh the license data.
	 *
	 * @return void
	 * @since 1.0.15 Updated to set properties.
	 */
	public function refresh() {
		if ( empty( $this->license() ) ) {
			return;
		}

		$cached = json_decode( wptravelengine_pro_get_license_status( '_wptravelengine_license_status', '{}' ) );

		$hit = null;
		if ( ! empty( $this->slug ) && isset( $cached->{$this->slug} ) ) {
			$hit = $cached->{$this->slug};
		} elseif ( ! empty( $cached ) ) {
			foreach ( $cached as $entry ) {
				if ( isset( $entry->item_id ) && (int) $entry->item_id === $this->item_id ) {
					$hit = $entry;
					break;
				}
			}
		}

		if ( null !== $hit ) {
			if ( isset( $hit->status ) || isset( $hit->license ) ) {
				$this->set_status( $hit->status ?? $hit->license );
			}
			$expiry = $hit->expiration ?? $hit->expires ?? null;
			if ( ! empty( $expiry ) ) {
				$this->set_expiry_datetime( $expiry );
			}
			if ( isset( $hit->license_limit ) ) {
				$this->set_limit( $hit->license_limit );
			}
			if ( isset( $hit->activations_left ) ) {
				$this->set_activations_left( $hit->activations_left );
			}
			if ( ! empty( $hit->customer_name ) ) {
				$this->set_customer_name( $hit->customer_name );
			}
			if ( ! empty( $hit->customer_email ) ) {
				$this->set_customer_email( $hit->customer_email );
			}
		}
	}

	/**
	 * Batch check all extension licenses via the /wp-json/edd-blc/v1/check-licenses endpoint.
	 * Saves results to _wptravelengine_license_status.
	 *
	 * @return array{success: bool, results: array<string, \stdClass>, message: string}
	 * @since 1.0.15
	 */
	public static function batch_check( $force = false ): array {
		$_license_status = wptravelengine_pro_get_license_status( '_wptravelengine_license_status', null );

		if ( ! $force && $_license_status ) {
			return array(
				'success' => true,
				'results' => $_license_status,
				'message' => __( 'License status already checked.', 'wptravelengine-pro' ),
			);
		}

		$extensions              = wptravelengine_pro_get_extensions();
		$indexed_extensions      = array();
		$license_key_by_item_id  = array();
		$licenses_payload        = array();

		foreach ( $extensions as $extension ) {
			$license_key = $extension->license_key();
			if ( empty( $license_key ) ) {
				continue;
			}
			$licenses_payload[]                        = array(
				'key'     => $license_key,
				'item_id' => $extension->ID,
				'url'     => is_multisite() ? network_site_url() : home_url(),
			);
			$indexed_extensions[ $extension->ID ]      = $extension->slug;
			$license_key_by_item_id[ $extension->ID ]  = $license_key;
		}

		if ( empty( $licenses_payload ) ) {
			return array(
				'success' => false,
				'results' => array(),
				'message' => __( 'No licenses to check.', 'wptravelengine-pro' ),
			);
		}

		$response = wp_remote_post(
			WP_TRAVEL_ENGINE_STORE_URL . '/wp-json/edd-blc/v1/check-licenses',
			array(
				'timeout' => 30,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode( array( 'licenses' => $licenses_payload ) ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'results' => array(),
				'message' => __( 'Remote request failed.', 'wptravelengine-pro' ),
			);
		}

		$response_code = wp_remote_retrieve_response_code( $response );

		if ( 429 === $response_code ) {
			set_site_transient( 'wptravelengine_site_forbidden', time(), 5 * MINUTE_IN_SECONDS );
			return array(
				'success' => false,
				'results' => array(),
				'message' => __( 'Remote request failed.', 'wptravelengine-pro' ),
			);
		}

		if ( 200 !== $response_code ) {
			return array(
				'success' => false,
				'results' => array(),
				'message' => __( 'Remote request failed.', 'wptravelengine-pro' ),
			);
		}

		$data = json_decode( wp_remote_retrieve_body( $response ) );

		if ( empty( $data->success ) || empty( $data->results ) ) {
			return array(
				'success' => false,
				'results' => array(),
				'message' => __( 'Invalid response from store.', 'wptravelengine-pro' ),
			);
		}

		$batch_status    = json_decode( wptravelengine_pro_get_license_status( '_wptravelengine_license_status', '{}' ) ) ?? new \stdClass();
		$results_by_slug = array();

		foreach ( $data->results as $result ) {
			$product_id = (int) ( $result->item_id ?? $result->download_id ?? 0 );
			$key        = $indexed_extensions[ $product_id ] ?? null;
			if ( $key ) {
				$result->item_id         = $product_id;
				$status_str              = $result->license ?? $result->status ?? '';
				$result->license         = $status_str;
				$result->error           = self::get_status_message( $status_str, $license_key_by_item_id[ $product_id ] ?? '' );
				$result->message         = $result->error;
				$batch_status->$key      = $result;
				$results_by_slug[ $key ] = $result;
			}
		}

		wptravelengine_pro_update_license_status( '_wptravelengine_license_status', wp_json_encode( $batch_status ) );

		return array(
			'success' => true,
			'results' => $results_by_slug,
			'message' => __( 'License statuses updated.', 'wptravelengine-pro' ),
		);
	}
}
